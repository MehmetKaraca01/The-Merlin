const conf = require("../../../../../a-sunucuayar.json")
const moment = require("moment")
moment.locale("tr");
const { red , green} = require("../../../../../a-emoji.json")
module.exports = {
  conf: {
    aliases: ["musician","muzisyen","müzisyen"],
    name: "musician",
    help: "musician",
  },

  run: async (client, message, args, embed, prefix) => {
if (!message.member.hasPermission("BAN_MEMBERS") &&  !conf.rolverici.some(x => message.member.roles.cache.has(x))) { message.channel.send("Yeterli yetkin bulunmuyor!").then(x=>x.delete({timeout:5000}))
message.react(red)
return }
let member = message.guild.member(message.mentions.users.first()) || message.guild.members.cache.get(args[0]);
if (!member) { message.channel.send( "Böyle bir kullanıcı bulunamadı!").then(x=>x.delete({timeout:5000}))
message.react(red)
return }
if(!member.roles.cache.has(conf.musician)){
message.react(green)
message.lineReply(`${member} kişisine başarıyla <@&${conf.musician}> rolü verildi!`).then(x=>x.delete({timeout:5000}))
await member.roles.add(conf.musician)
} else {
message.react(green)
message.lineReply(`${member} kişisinden başarıyla <@&${conf.musician}> rolü alındı!`).then(x=>x.delete({timeout:5000}))
await member.roles.remove(conf.musician)
}}
};