# Ozi Welcome

- Sizleri geliştirmiş olduğum welcome botlardan biriyle tanıştırmak istiyorum.. 
- Çok tokenli basit gelismis welcome bot.
- Sağ üst kısımdan Star atarak destek olabilirsiniz.

![image](https://user-images.githubusercontent.com/92666466/139590930-5e12f459-1b8b-4347-811f-2e8f1cb3b676.png)
