# OZİ BOTS SS
![image](https://user-images.githubusercontent.com/92666466/141508588-efd16297-700d-41af-9a64-a5f14f0316b3.png)
![image](https://user-images.githubusercontent.com/92666466/141027859-8fd86201-d257-473d-8022-1edf8e052044.png)
![image](https://user-images.githubusercontent.com/92666466/141027606-097f7300-47f4-42d4-a230-42faa1c12546.png)
![image](https://user-images.githubusercontent.com/92666466/141028898-ef3e2cad-7209-415a-8a84-201c6e976f9a.png)
![image](https://user-images.githubusercontent.com/92666466/139575506-c3d8b1cd-dab1-4c4a-8fc0-89e52b1148df.png)
![image](https://user-images.githubusercontent.com/92666466/139575391-c1c267fe-eee9-41c0-b821-cf90ca1c8641.png)
![image](https://user-images.githubusercontent.com/92666466/139575398-a0863b73-e2f0-4982-901d-6fc223640dae.png)
![image](https://user-images.githubusercontent.com/92666466/139575436-b1a629cf-340f-47f2-bf70-cead3f3d49bc.png)
![image](https://user-images.githubusercontent.com/92666466/139575377-ade118e3-c9b5-4bc8-a3b4-447fdc6325e6.png)
![image](https://user-images.githubusercontent.com/92666466/139575560-f6cd46be-5f2f-42b6-adbf-079aa835da73.png)
![image](https://user-images.githubusercontent.com/92666466/139575586-93156301-2cc4-45c2-a167-b82d51fa846f.png)
![image](https://user-images.githubusercontent.com/92666466/140218451-006119ee-7a23-41ce-8f1d-bf8c42f0b560.png)
![image](https://user-images.githubusercontent.com/92666466/139575596-53f98cee-5570-4bff-ad13-20393edb2470.png)
![image](https://user-images.githubusercontent.com/92666466/139575625-fac22ea2-5911-41b9-9692-9de1d896bd3b.png)
![image](https://user-images.githubusercontent.com/92666466/139575362-1562a395-5352-4528-b336-5400ef7abe11.png)
![image](https://user-images.githubusercontent.com/92666466/139575369-b977aef8-b890-451f-bb9b-b6797ab6cc67.png)
![image](https://user-images.githubusercontent.com/92666466/139575301-3eb0eb45-8327-49c8-85fe-71fbc39476b3.png)
![image](https://user-images.githubusercontent.com/92666466/139575381-c6cef99a-3dd2-4c43-b208-e7faa3233774.png)
![image](https://user-images.githubusercontent.com/92666466/139575656-0f8e35da-e696-4a6a-a3c7-5342af53de8d.png)
![image](https://user-images.githubusercontent.com/92666466/139575672-a7f84db7-98af-46c5-9f37-b2dbfc5fd729.png)

# OZİ BACKUP

![image](https://user-images.githubusercontent.com/92666466/143085087-54b461fe-526d-4e48-9bb7-497b8a444511.png)
![image](https://user-images.githubusercontent.com/92666466/143085098-f153f296-6c92-4c87-9daa-df4cb5930d9b.png)
![image](https://user-images.githubusercontent.com/92666466/143085113-22289ea1-0e99-4a84-95de-54b6da12ecd7.png)
![image](https://user-images.githubusercontent.com/92666466/143085125-1503cd4e-c3c0-4503-9172-1e315c578776.png)
![image](https://user-images.githubusercontent.com/92666466/143085137-4703e78b-d365-4d33-aa65-c9a610e04d67.png)
![image](https://user-images.githubusercontent.com/92666466/143087025-572d7f7f-653b-4373-9eb5-85b16c1621c1.png)
![image](https://user-images.githubusercontent.com/92666466/143089451-765b4551-0752-4f4b-95ca-98ce79cdb55a.png)

# OZİ GUARDS

![image](https://user-images.githubusercontent.com/92666466/139727759-dbf9ef2b-5d9b-46fe-b96d-6e95d2d07a0b.png)
