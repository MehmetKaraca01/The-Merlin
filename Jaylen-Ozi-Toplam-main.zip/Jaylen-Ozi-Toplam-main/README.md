# Jaylen Bots

Jaylen Ozi'nin githubundaki altyapıları editleyip sizlere veriyorum kolay gelsin.

**Not: Bu altyapıyı düzenleyip paylaşmak için Jaylen'den izin aldım.**

![image](https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif)

# Hesaplarımız
__Discord__

[Passenger](https://discord.com/users/798257622033367070)

[Jaylen-Ozi](https://discord.com/users/612688335944679600)

__GİTHUB__

[Passenger-Github](https://github.com/Passengerrr)

[Jaylen-Ozi-Github](https://github.com/JaylenOzi)

![image](https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif)

# Altyapı Linkleri

[Ozi-Bots](https://github.com/JaylenOzi/Ozi-Bots)

[Ozi-Backup](https://github.com/JaylenOzi/Ozi-Backup)

[Ozi-Guards](https://github.com/JaylenOzi/Ozi-Guards)

[Ozi-Welcome](https://github.com/JaylenOzi/Ozi-Welcome)

**Bot sslerini görmek için botssler e bakabilirsiniz**
